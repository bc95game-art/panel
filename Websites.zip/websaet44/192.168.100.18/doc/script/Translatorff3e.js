/**********************************
*Title:Translator.js
*Author:pyy
*Company:TaoShi
*Describe:���������
***********************************/

function Translator()
{
	this.szCurLanguage = null; // ԭm_szLanguage
	var that = this;

	/*************************************************
	Function:		appendLanguageXmlDoc
	Description:	��lxd�ϲ���lxdObj�����غϲ����lxd
	Input:			lxdObj: ���ϲ���lxd
					lxd: ���ںϲ���lxd�������ı�
	Output:			lxdObj: �ϲ����lxdͬ����ֵ
	return:			�ϲ����lxd
	*************************************************/
	this.appendLanguageXmlDoc = function(lxdObj, lxd) {
		if (lxdObj === null && lxd !== null) {
			return (this.s_lastLanguageXmlDoc = lxd);
		} else if (lxdObj !== null && lxd === null) {
			return (this.s_lastLanguageXmlDoc = lxdObj);
		} else if (lxdObj === null && lxd === null) {
			return (this.s_lastLanguageXmlDoc = null);
		} else {
			return (this.s_lastLanguageXmlDoc = $(lxdObj).append($(lxd.cloneNode(true)).children())[0]);
		}
	}
	
	/*************************************************
	Function:		getLanguageXmlDoc
	Description:	����ָ�����Ա�ʾ����XML���ƣ���ȡLanguageXmlDoc����ָ��szLanguage������this.szCurLanguage
	Input:			szXmls: (String)XML���ƣ�������׺������(Array)XML���Ƽ�������ڵ���ɵ�����
					szLanguage: ���Ա�ʾ�������ļ���������ʡ�ԣ�Ĭ��this.szCurLanguage��
	Output:			��
	return:			ָ�����Ե�LanguageXmlDoc
	*************************************************/
	this.getLanguageXmlDoc = function(szXmls, szLanguage, bMergeCommon) {
		if (szLanguage !== undefined) {
			this.szCurLanguage = szLanguage;
		}
		if (typeof szXmls === "string") {
			szXmls = [szXmls];
		}
		$.each(szXmls, function(i, szXml) {
			szXmls[i] = szXml.replace(/^(\d)/, "_$1");
		});
		var lxd;
		$.ajax({
			url: "../xml/" + this.szCurLanguage + "/" + szXmls[0] + ".xml?v"+new Date().getTime(),
			type: "get",
			async: false,
			cache: true,
			dataType: "xml",
			error: function(xml, textStatus, errorThrown) {
				alert("Error loading XML document" + xml); // �����ļ�������󣬻�XML����׼
			},
			success:function(xml)
			{
				lxd=xml;
			}
		})
		var lxdCommon = undefined;
		$.each(szXmls, function(i, szXml) {
			if (i === 1) {
				lxdCommon = $(lxd).children("Common")[0];
			}
			lxd = $(lxd).children(szXml)[0];
		});
		if (lxdCommon !== undefined && bMergeCommon !== false) {
			//this.appendLanguageXmlDoc(lxd, lxdCommon);
			$(lxd).append($(lxdCommon).children());
		}
		return (this.s_lastLanguageXmlDoc = lxd);
	}
	
	/*************************************************
	Function:		translateElements
	Description:	����ָ���ĵ���ĳ���ǩ
	Input:			languageXmlDoc: ͨ��getLanguageXmlDoc��ȡ��LanguageXmlDoc
					doc: ָ���ĵ�
					szTag: ��ǩ����
					szProp: ��������
					szKey: ���ڷ���ļ�����"id"��"name"��"class"��Ĭ��"name"
	Output:			��
	return:			��
	*************************************************/
	this.translateElements = function(languageXmlDoc, doc, szTag, szProp, szKey)
	{
		if (szKey === undefined) {
			szKey = "name";
		}
		$(doc).find(szTag).each(function(i) {
			var szTranslated = $(languageXmlDoc).find($(this).attr(szKey)).eq(0).text(); // ����ɽ�һ���Ż�, wuyang
			if (szTranslated !== "") {
				if (szTag === "label" || szTag === "a") {
					szTranslated = szTranslated.replace(/ /g,"&nbsp;");
				}
				switch (szProp) {
					case "innerHTML":
						$(this).html(szTranslated);
						break;
					case "innerText":
						$(this).text(szTranslated);
						break;
					case "value":
						$(this).val(szTranslated);
						break;
					default:
						$(this).attr(szProp, szTranslated);
						break;
				}
			}
		});
	}
	
	/*************************************************
	Function:		translatePage
	Description:	����ָ���ĵ�
	Input:			languageXmlDoc: ͨ��getLanguageXmlDoc��ȡ��LanguageXmlDoc
					doc: ָ���ĵ�
					szKey: ���ڷ���ļ�����"id"��"name"��"class"��Ĭ��"name"
	Output:			��
	return:			��
	*************************************************/
	this.translatePage = function(languageXmlDoc, doc, szKey) {
		if (doc === undefined) {
			doc = document;
		}
		if (szKey === undefined) {
			szKey = "name";
		}
		// ����ɽ�һ���Ż���wuyang
		this.translateElements(languageXmlDoc, doc, "input", "value", szKey);
		this.translateElements(languageXmlDoc, doc, "label", "innerHTML", szKey);
		this.translateElements(languageXmlDoc, doc, "option", "innerText", szKey);
		this.translateElements(languageXmlDoc, doc, "a", "innerHTML", szKey);
		var that = this;
		if (translateTailor.bEnable) {
			setTimeout(function() {
			}, 10);
		}
	}
	
	/*************************************************
	Function:		translateNode
	Description:	����ָ���ڵ�
	Input:			languageXmlDoc: ͨ��getLanguageXmlDoc��ȡ��LanguageXmlDoc
					nodeName: XML�еĽڵ���
	Output:			��
	return:			������
	*************************************************/
	this.translateNode = function(languageXmlDoc, nodeName)
	{
		try
		  {
			return $(languageXmlDoc).find(nodeName).text();
		  }
		catch(err)
		  {
		  return null;
 		 }
	}
}

Translator.prototype = {
	constructor: Translator,
	s_lastLanguageXmlDoc: null,
	translateNodeByLastLxd: function(nodeName) { // ģ��ԭgetNodeValude
		if (this.s_lastLanguageXmlDoc === null) {
			return;
		}
		var str=translator.translateNode(this.s_lastLanguageXmlDoc, nodeName);
		if(str==null || str=="")
			return nodeName;
		else
			return str;
	}
}

/*************************************************
Function:		TransStack
Description:	����ص���ջ��
Input:			��
Output:			��
return:			��
*************************************************/
function TransStack()
{
	var _cbTransStack = [];

	this.clear = function() {
		_cbTransStack = [];
	}

	this.push = function(cbFun, bSync) {
		if (bSync === true) {
			cbFun();
		}
		_cbTransStack.push(cbFun);
	}
	
	this.pop = function() {
		return _cbTransStack.pop();
	}
	
	this.translate = function() {
		$.each(_cbTransStack, function(i, cbTrans) {
			cbTrans();
		});
	}
	
	this.getLength = function() {
		return _cbTransStack.length;
	}
}

/*************************************************
Function:		TranslateTailor
Description:	�����ַ������ڱ�ǩ���ͺ����Ƴ��ȵ��Զ���
Input:			��
Output:			��
return:			��
*************************************************/
function TranslateTailor()
{
	this.bEnable = false;
	try {
		var _fso = null;//new ActiveXObject("Scripting.FileSystemObject");
	} catch (e) { }
	
	this.clearXmlFiles = function(szPath, szXmls, szLanguage) {
		if (!this.bEnable) {
			return;
		}
		if (typeof szXmls === "string") {
			szXmls = [szXmls];
		}
		$.each(szXmls, function(i, szXml) {
			_clearPage(szPath + "/" + szLanguage + "/" + szXml + ".xml?v"+new Date().getTime(), szLanguage);
		});
	}
	
	function _clearPage(szXmlPath, szLanguage) {
		var szXmlDoc = _readFile(szXmlPath);
		var lxd = parseXmlFromStr(szXmlDoc);
		
		$.each($(lxd).find("*"), function(i, elem) {
			$(elem).removeAttr("tag").removeAttr("length");
		})

		_writeFile(lxd.xml, szXmlPath);
	}
	
	this.sewXmlFiles = function(szPath, szXmls, szLanguage, doc, szKey) {
		if (!this.bEnable) {
			return;
		}
		if (typeof szXmls === "string") {
			szXmls = [szXmls];
		}
		$.each(szXmls, function(i, szXml) {
			_measurePage(szPath + "/" + szLanguage + "/" + szXml + ".xml?v"+new Date().getTime(), szLanguage, doc, szKey);
		});
	}
	
	function _measureElements(languageXmlDoc, doc, szTag, szKey)
	{
		if (szKey === undefined) {
			szKey = "name";
		}
		$(doc).find(szTag).each(function(i) {
			if ($(languageXmlDoc).find($(this).attr(szKey)).length !== 0) {
				var elemXmlDoc = $(languageXmlDoc).find($(this).attr(szKey))[0];
				var szElemTag = $(elemXmlDoc).attr("tag");
				if (szElemTag === undefined) {
					szElemTag = "";
				}
				if (-1 === szElemTag.indexOf(szTag + ";")) {
					$(elemXmlDoc).attr("tag", szElemTag + szTag + ";");
				}
				var szElemLength = $(elemXmlDoc).attr("length");
				switch (szTag) {
					case "option":
						var iWidth = $(this).parent("select").eq(0).width();
						break;
					case "a":
						if ($(this).parent().get(0).tagName === "LI") {
							iWidth = 9999; // ������ҳ���a��ǩ
							break;
						}
					case "label":
						var iWidth = 9999;
						var $ancestor = $(this);
						var $ancestor2 = null; // ��ڵ���$ancestor��child
						while ($ancestor.length !== 0) {
							if ($ancestor.css("display") === "block" || $ancestor.css("display") === "inline-block" || $ancestor.css("display") === "table-cell") {
								iWidth = $ancestor.width();
								break;
							}
							$ancestor2 = $ancestor;
							$ancestor = $ancestor.parent();
						}
						if ($ancestor2 !== null && $ancestor2.css("text-align") === "left") {
							var ancestor2Next = $ancestor2.next().get(0);
							if (ancestor2Next === undefined) {
								iWidth = $ancestor.position().left + $ancestor.width() - $ancestor2.position().left;
							} else if (ancestor2Next !== undefined && $(ancestor2Next).position().top <= $ancestor2.position().top + $ancestor2.height()) {
								iWidth = Math.abs($ancestor2.position().left - $(ancestor2Next).position().left); // ����Ϊʲô��ʱ�Ǹ�������
							}
						}
						break;

					default: // "input"��"img"
						var iWidth = $(this).width();
						break;
				}

				if (iWidth > 0 && (szElemLength === undefined || szElemLength === "0" || szElemLength > iWidth)) {
					$(elemXmlDoc).attr("length", iWidth);
				}
			}
		});
	}
	
	function _measurePage(szXmlPath, szLanguage, doc, szKey) {		
		if (doc === undefined) {
			doc = document;
		}
		if (szKey === undefined) {
			szKey = "name";
		}
		
		var szXmlDoc = _readFile(szXmlPath);
		var lxd = parseXmlFromStr(szXmlDoc);

		_measureElements(lxd, doc, "input", szKey);
		_measureElements(lxd, doc, "label", szKey);
		_measureElements(lxd, doc, "img", szKey);
		_measureElements(lxd, doc, "option", szKey);
		_measureElements(lxd, doc, "a", szKey);
		
		_writeFile(lxd.xml, szXmlPath);
	}
	
	function _readFile(szPath) {
		var szContent = "";
		try {
			var reader = _fso.OpenTextFile(szPath, 1, false, 0);
			while (!reader.AtEndofStream) {
				szContent += reader.readline();
				szContent += "\n";
			}
			reader.close();
		} catch(e) { }
		return szContent;
	}
	
	function _writeFile(szContent, szPath){
		try {
		   var writer = _fso.CreateTextFile(szPath, true);
		   writer.WriteLine(szContent);
		   writer.Close();
		} catch (e) { }
	}
}

var translateTailor = new TranslateTailor();
var translator = new Translator();
