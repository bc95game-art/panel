"""
⌨️ All Keyboards
"""
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, ReplyKeyboardRemove


# ── Welcome ──
def kb_welcome():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🟢 وارد کردن پسورد کاربری 🔴", callback_data="ask_password")]
    ])


# ── Main Menu ──
def kb_main_menu():
    return ReplyKeyboardMarkup([
        ["📁 اجرا ربات تلگرامی با کد فایل 🔥"],
        ["📁 اجرا ربات تلگرامی با کد فایل ZIP 🔥"],
        ["👤 پنل کاربری مشخصات کاربر ♻️"],
        ["💰 پنل مدیریت ربات های اجرا شده 📡"],
        ["☎️ پشتیبانی ـ admin 🟢"],
    ], resize_keyboard=True)


# ── Back to main ──
def kb_back_main():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📡 بازگشت به منوی اصلی ♻️", callback_data="back_main")]
    ])


# ── Section A: language select ──
def kb_a_lang():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("زبان اول 🐘 PHP", callback_data="a_php")],
        [InlineKeyboardButton("زبان دوم 🐍 Python", callback_data="a_py")],
        [InlineKeyboardButton("📡 بازگشت به منوی اصلی ♻️", callback_data="back_main")],
    ])


# ── Section A: file step buttons (PHP) ──
# step: 1..10, file_count: how many uploaded so far
PHP_CONTINUE_EMOJIS = ["", "🔥", "📶", "🔥", "💰", "♦️", "➕", "🟢", "⚪", "🟠", "♻️"]
PHP_RUN_EMOJIS      = ["", "🔥", "📶", "⏳", "💰", "♦️", "➕", "🟢", "⚪", "🟠", "♻️"]

PY_CONTINUE_EMOJIS  = ["", "📳", "👤", "🌱", "📡", "🥇", "📢", "🏆", "📌", "💣", "🛡️"]
PY_RUN_EMOJIS       = ["", "📳", "👤", "🌱", "📡", "🥇", "📢", "🏆", "📌", "💣", "🛡️"]


def kb_a_php_file(step: int):
    em_run  = PHP_RUN_EMOJIS[step]
    em_cont = PHP_CONTINUE_EMOJIS[step]
    buttons = [
        [InlineKeyboardButton(f"{em_run} اجرا کامل ربات 📁", callback_data=f"a_php_run_{step}")]
    ]
    if step < 10:
        buttons.append([InlineKeyboardButton(f"{em_cont} ادامه فایل ها 📁", callback_data=f"a_php_next_{step}")])
    buttons.append([InlineKeyboardButton("📡 بازگشت به منوی اصلی ♻️", callback_data="back_main")])
    return InlineKeyboardMarkup(buttons)


def kb_a_py_file(step: int):
    em_run  = PY_RUN_EMOJIS[step]
    em_cont = PY_CONTINUE_EMOJIS[step]
    buttons = [
        [InlineKeyboardButton(f"{em_run} اجرا کامل ربات 📁", callback_data=f"a_py_run_{step}")]
    ]
    if step < 10:
        buttons.append([InlineKeyboardButton(f"{em_cont} ادامه فایل ها 📳", callback_data=f"a_py_next_{step}")])
    buttons.append([InlineKeyboardButton("📡 بازگشت به منوی اصلی ♻️", callback_data="back_main")])
    return InlineKeyboardMarkup(buttons)


# ── Section B: language select ──
def kb_b_lang():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("〽️ زبان اول 🐘 PHP", callback_data="b_php")],
        [InlineKeyboardButton("〽️ زبان دوم 🐍 Python", callback_data="b_py")],
        [InlineKeyboardButton("📡 بازگشت به منوی اصلی ♻️", callback_data="back_main")],
    ])


# ── Section B: after ZIP received ──
def kb_b_php_run():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("〽️ اجرا کامل ربات 🗜️", callback_data="b_php_run")],
        [InlineKeyboardButton("📡 بازگشت به منوی اصلی ♻️", callback_data="back_main")],
    ])


def kb_b_py_run():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("〽️ اجرا کامل ربات 🗜️", callback_data="b_py_run")],
        [InlineKeyboardButton("📡 بازگشت به منوی اصلی ♻️", callback_data="back_main")],
    ])


# ── Section D: manage bot ──
def kb_d_manage(bot_id: int):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ فعال‌سازی ربات", callback_data=f"d_activate_{bot_id}")],
        [InlineKeyboardButton("❌ غیرفعال‌سازی ربات", callback_data=f"d_deactivate_{bot_id}")],
        [InlineKeyboardButton("🗑️ حذف ربات", callback_data=f"d_delete_{bot_id}")],
    ])


def kb_d_confirm_delete(bot_id: int):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ بله، حذف شود", callback_data=f"d_confirm_del_{bot_id}")],
        [InlineKeyboardButton("❌ خیر، انصراف", callback_data=f"d_cancel_del_{bot_id}")],
    ])
