"""
👤 Section C - پنل کاربری
"""
from telegram import Update
from telegram.ext import ContextTypes
from handlers.keyboards import kb_back_main
from utils.database import get_user_stats


async def enter_section_c(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    stats = await get_user_stats(user.id)

    await update.message.reply_text(
        f"👤 پنل کاربری | {user.first_name} عزیز\n"
        "━━━━━━━━━━━━━━━\n"
        "📋 اطلاعات حساب کاربری\n"
        "━━━━━━━━━━━━━━━\n"
        f"🆔 آیدی تلگرام: {user.id}\n"
        f"📛 نام کاربری: @{user.username or 'ندارد'}\n"
        f"📅 تاریخ عضویت: {stats['joined']}\n"
        "━━━━━━━━━━━━━━━\n"
        "🤖 آمار ربات‌های اجرا شده\n"
        "━━━━━━━━━━━━━━━\n"
        f"📊 کل ربات‌های اجرا شده: {stats['total']}\n"
        f"تعداد ربات اجرا شد با زبان 🐘 PHP : {stats['php']}\n"
        f"تعداد ربات اجرا شده با زبان 🐍 Python : {stats['python']}\n"
        "━━━━━━━━━━━━━━━\n"
        "📦 آمار نوع اجرا\n"
        "━━━━━━━━━━━━━━━\n"
        f"📁 اجرا از طریق فایل مستقیم: {stats['direct']} ربات\n"
        f"🗜️ اجرا از طریق فایل ZIP: {stats['zip']} ربات\n"
        "━━━━━━━━━━━━━━━\n"
        f"🟢 ربات‌های فعال: {stats['active']}\n"
        f"🔴 ربات‌های غیرفعال: {stats['inactive']}\n"
        "━━━━━━━━━━━━━━━\n\n"
        "🏠 برای بازگشت به منوی اصلی از دکمه زیر اقدام کنید 👇",
        reply_markup=kb_back_main(),
    )
