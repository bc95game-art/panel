"""
📌 All conversation states
"""

# Auth
WAIT_PASSWORD = "WAIT_PASSWORD"

# Main menu
MAIN_MENU = "MAIN_MENU"

# Section A - Direct file
A_LANG_SELECT = "A_LANG_SELECT"
A_PHP_FILE = "A_PHP_FILE"         # waiting file upload (php, step N)
A_PY_FILE = "A_PY_FILE"           # waiting file upload (python, step N)
A_PHP_PROJECT_NAME = "A_PHP_PROJECT_NAME"
A_PY_PROJECT_NAME = "A_PY_PROJECT_NAME"

# Section B - ZIP
B_LANG_SELECT = "B_LANG_SELECT"
B_PHP_ZIP = "B_PHP_ZIP"
B_PY_ZIP = "B_PY_ZIP"
B_PHP_PROJECT_NAME = "B_PHP_PROJECT_NAME"
B_PY_PROJECT_NAME = "B_PY_PROJECT_NAME"

# Section D - manage
D_CONFIRM_DELETE = "D_CONFIRM_DELETE"
