"""
💰 Section D - پنل مدیریت ربات‌ها
"""
import logging
from telegram import Update
from telegram.ext import ContextTypes
from handlers.keyboards import kb_d_manage, kb_d_confirm_delete, kb_back_main, kb_main_menu
from utils.database import get_user_bots, update_bot_status, delete_bot
from config import Config

logger = logging.getLogger(__name__)


async def enter_section_d(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """نمایش لیست ربات‌های کاربر"""
    user = update.effective_user
    bots = await get_user_bots(user.id)

    if not bots:
        await update.message.reply_text(
            f"👤 {user.first_name} عزیز، به پنل مدیریت ربات‌ها خوش اومدی!\n\n"
            "📭 هنوز هیچ ربات اجرا‌شده‌ای ندارید.\n\n"
            "🏠 برای بازگشت به منوی اصلی از دکمه زیر اقدام کنید 👇",
            reply_markup=kb_back_main(),
        )
        return

    for bot in bots:
        bot_id, uid, project_name, language, run_type, status, created_at = bot
        lang_emoji = "🐘" if language == "PHP" else "🐍"
        status_text = "🟢 فعال" if status == "active" else "🔴 غیرفعال"

        await update.message.reply_text(
            f"👤 {user.first_name} عزیز، به پنل مدیریت ربات‌ها خوش اومدی!\n\n"
            "━━━━━━━━━━━━━━━\n"
            "🤖 اطلاعات ربات\n"
            "━━━━━━━━━━━━━━━\n"
            f"📛 نام پروژه: {project_name}\n"
            f"{lang_emoji} زبان ربات: {language}\n"
            f"📦 نوع اجرا: {'فایل مستقیم' if run_type == 'direct' else 'فایل ZIP'}\n"
            f"📅 تاریخ اجرا: {created_at}\n"
            f"وضعیت فعلی: {status_text}\n"
            "━━━━━━━━━━━━━━━\n\n"
            "⚙️ از دکمه‌های زیر برای مدیریت ربات خود اقدام کنید 👇\n\n"
            "✅ فعال‌سازی ربات\n"
            "❌ غیرفعال‌سازی ربات\n"
            "🗑️ حذف ربات\n\n"
            "⚠️ توجه: امکان ویرایش کد ربات در این بخش وجود ندارد.\n\n"
            "🍀 موفق و پیروز باشید!",
            reply_markup=kb_d_manage(bot_id),
        )


async def cb_d_activate(update: Update, context: ContextTypes.DEFAULT_TYPE, bot_id: int):
    query = update.callback_query
    await query.answer()
    user = query.from_user

    await update_bot_status(bot_id, "active")
    bots = await get_user_bots(user.id)
    project_name = next((b[2] for b in bots if b[0] == bot_id), "نامشخص")

    await query.message.reply_text(
        f"✅ {user.first_name} عزیز، تبریک!\n\n"
        "🟢 ربات شما با موفقیت فعال شد!\n\n"
        "━━━━━━━━━━━━━━━\n"
        f"📛 نام پروژه: {project_name}\n"
        "🟢 وضعیت: فعال\n"
        "━━━━━━━━━━━━━━━\n\n"
        "❓ در صورت بروز هرگونه مشکل یا سوال با پشتیبانی تماس بگیرید 👇\n"
        f"📩 {Config.SUPPORT_USERNAME}\n\n"
        "🏠 برای بازگشت به منوی اصلی از دکمه زیر اقدام کنید 👇\n"
        "🍀 موفق باشید!",
        reply_markup=kb_back_main(),
    )


async def cb_d_deactivate(update: Update, context: ContextTypes.DEFAULT_TYPE, bot_id: int):
    query = update.callback_query
    await query.answer()
    user = query.from_user

    await update_bot_status(bot_id, "inactive")
    bots = await get_user_bots(user.id)
    project_name = next((b[2] for b in bots if b[0] == bot_id), "نامشخص")

    await query.message.reply_text(
        f"🔴 {user.first_name} عزیز،\n\n"
        "ربات شما با موفقیت غیرفعال شد!\n\n"
        "━━━━━━━━━━━━━━━\n"
        f"📛 نام پروژه: {project_name}\n"
        "🔴 وضعیت: غیرفعال\n"
        "━━━━━━━━━━━━━━━\n\n"
        "⚠️ توجه: تا زمانی که ربات را مجدداً فعال نکنید، پاسخگوی کاربران نخواهد بود.\n\n"
        "❓ در صورت بروز هرگونه مشکل یا سوال با پشتیبانی تماس بگیرید 👇\n"
        f"📩 {Config.SUPPORT_USERNAME}\n\n"
        "🏠 برای بازگشت به منوی اصلی از دکمه زیر اقدام کنید 👇\n"
        "🍀 موفق باشید!",
        reply_markup=kb_back_main(),
    )


async def cb_d_delete_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE, bot_id: int):
    """نمایش تأییدیه حذف"""
    query = update.callback_query
    await query.answer()
    user = query.from_user

    bots = await get_user_bots(user.id)
    project_name = next((b[2] for b in bots if b[0] == bot_id), "نامشخص")

    await query.message.reply_text(
        f"🗑️ {user.first_name} عزیز،\n\n"
        "آیا از حذف ربات خود اطمینان دارید؟\n\n"
        "━━━━━━━━━━━━━━━\n"
        f"📛 نام پروژه: {project_name}\n"
        "⚠️ وضعیت: در انتظار تأیید حذف\n"
        "━━━━━━━━━━━━━━━\n\n"
        "❗️ توجه: پس از حذف ربات، این عملیات غیرقابل بازگشت است و تمام اطلاعات پروژه حذف خواهد شد.\n\n"
        "آیا مطمئن هستید؟ 👇",
        reply_markup=kb_d_confirm_delete(bot_id),
    )


async def cb_d_do_delete(update: Update, context: ContextTypes.DEFAULT_TYPE, bot_id: int):
    """اجرای حذف"""
    query = update.callback_query
    await query.answer()
    user = query.from_user

    bots = await get_user_bots(user.id)
    project_name = next((b[2] for b in bots if b[0] == bot_id), "نامشخص")

    await delete_bot(bot_id)

    await query.message.reply_text(
        f"🗑️ {user.first_name} عزیز،\n\n"
        "ربات شما با موفقیت حذف شد!\n\n"
        "━━━━━━━━━━━━━━━\n"
        f"📛 نام پروژه: {project_name}\n"
        "⛔️ وضعیت: حذف شده\n"
        "━━━━━━━━━━━━━━━\n\n"
        "❓ در صورت بروز هرگونه مشکل یا سوال با پشتیبانی تماس بگیرید 👇\n"
        f"📩 {Config.SUPPORT_USERNAME}\n\n"
        "🏠 برای بازگشت به منوی اصلی از دکمه زیر اقدام کنید 👇\n"
        "🍀 موفق باشید!",
        reply_markup=kb_back_main(),
    )


async def cb_d_cancel_delete(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """انصراف از حذف → برگشت به پنل"""
    query = update.callback_query
    await query.answer()
    user = query.from_user

    await query.message.reply_text(
        f"❌ عملیات حذف لغو شد.\n\n"
        "🔄 در حال بازگشت به پنل مدیریت...",
    )
    # نمایش مجدد پنل
    bots = await get_user_bots(user.id)
    for bot in bots:
        bot_id, uid, project_name, language, run_type, status, created_at = bot
        lang_emoji = "🐘" if language == "PHP" else "🐍"
        status_text = "🟢 فعال" if status == "active" else "🔴 غیرفعال"

        await query.message.reply_text(
            f"━━━━━━━━━━━━━━━\n"
            f"📛 نام پروژه: {project_name}\n"
            f"{lang_emoji} زبان: {language}\n"
            f"وضعیت: {status_text}\n"
            "━━━━━━━━━━━━━━━",
            reply_markup=kb_d_manage(bot_id),
        )
