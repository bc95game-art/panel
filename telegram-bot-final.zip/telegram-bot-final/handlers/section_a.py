"""
📁 Section A - اجرا ربات با فایل مستقیم
"""
import asyncio
import logging
import os
import tempfile
from datetime import datetime
from telegram import Update
from telegram.ext import ContextTypes
from handlers.keyboards import kb_a_lang, kb_a_php_file, kb_a_py_file, kb_back_main
from utils.helpers import validate_file, simulate_run_bot
from utils.database import add_bot
from config import Config

logger = logging.getLogger(__name__)

NUMS_FA = ["", "اول", "دوم", "سوم", "چهارم", "پنجم", "ششم", "هفتم", "هشتم", "نهم", "دهم"]


async def enter_section_a(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """ورود به بخش A از منوی اصلی"""
    user = update.effective_user
    context.user_data["section"] = "A"
    context.user_data["a_files"] = []
    context.user_data["a_step"] = 0
    context.user_data["a_lang"] = None
    context.user_data["state"] = "A_LANG_SELECT"

    await update.message.reply_text(
        f"👋 سلام {user.first_name} عزیز!\n\n"
        "🤖 برای اجرای ربات تلگرامی، لطفاً زبان برنامه‌نویسی مورد نظر خود را انتخاب کنید 👇\n\n"
        "⚙️ سیستم ما از دو زبان پیشرفته پشتیبانی می‌کند:\n\n"
        "🐘 PHP\n"
        "🐍 Python\n\n"
        "🍀 موفق باشید!",
        reply_markup=kb_a_lang(),
    )


async def cb_a_select_lang(update: Update, context: ContextTypes.DEFAULT_TYPE, lang: str):
    """انتخاب زبان در بخش A"""
    query = update.callback_query
    await query.answer()
    user = query.from_user
    context.user_data["a_lang"] = lang
    context.user_data["a_step"] = 1
    context.user_data["a_files"] = []
    context.user_data["state"] = f"A_{lang.upper()}_FILE"

    emoji = "🐘" if lang == "PHP" else "🐍"
    await query.message.reply_text(
        f"✅ {user.first_name} عزیز، زبان {emoji} {lang} با موفقیت انتخاب شد!\n\n"
        "📂 حالا فایل‌های ربات خود را ارسال کنید 👇\n\n"
        "📌 نکته: می‌توانید تا ۱۰ فایل برای یک ربات آپلود کنید.\n"
        "📊 وضعیت آپلود: 0 از 10 فایل",
    )


async def handle_file_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """دریافت فایل در بخش A"""
    user = update.effective_user
    lang = context.user_data.get("a_lang", "Python")
    step = context.user_data.get("a_step", 1)
    files = context.user_data.get("a_files", [])

    doc = update.message.document
    if not doc:
        await update.message.reply_text(
            f"❌ {user.first_name} عزیز، فایل ارسالی نامعتبر است!\n\n"
            "⚠️ احتمالی دلایل:\n"
            "🔹 فرمت فایل پشتیبانی نمی‌شود\n"
            "🔹 فایل آسیب‌دیده یا ناقص است\n"
            "🔹 ساختار فایل دارای مشکل است\n\n"
            "🔄 لطفاً فایل را بررسی کرده و دوباره ارسال کنید.\n"
            f"در صورت ادامه مشکل با پشتیبانی تماس بگیرید 👇\n"
            f"📩 {Config.SUPPORT_USERNAME}",
        )
        return

    filename = doc.file_name or "file"
    if not validate_file(filename, lang):
        await update.message.reply_text(
            f"❌ {user.first_name} عزیز، فایل ارسالی نامعتبر است!\n\n"
            "⚠️ احتمالی دلایل:\n"
            "🔹 فرمت فایل پشتیبانی نمی‌شود\n"
            "🔹 فایل آسیب‌دیده یا ناقص است\n"
            "🔹 ساختار فایل دارای مشکل است\n\n"
            "🔄 لطفاً فایل را بررسی کرده و دوباره ارسال کنید.\n"
            f"در صورت ادامه مشکل با پشتیبانی تماس بگیرید 👇\n"
            f"📩 {Config.SUPPORT_USERNAME}",
        )
        return

    files.append(filename)
    context.user_data["a_files"] = files
    count = len(files)

    num_fa = NUMS_FA[count] if count <= 10 else str(count)
    kb = kb_a_php_file(step) if lang == "PHP" else kb_a_py_file(step)

    await update.message.reply_text(
        f"✅ {user.first_name} عزیز، فایل {num_fa} با موفقیت دریافت شد! 🟢\n\n"
        f"📊 وضعیت آپلود: {count} از ۱۰ فایل\n\n"
        "📂 فایل بعدی را ارسال کنید یا در صورتی که همه فایل‌ها آپلود شدند، روی دکمه اجرای ربات بزنید 👇\n\n"
        "📌 یادآوری: امکان آپلود تا ۱۰ فایل برای یک ربات وجود دارد.",
        reply_markup=kb,
    )


async def cb_a_run(update: Update, context: ContextTypes.DEFAULT_TYPE, lang: str, step: int):
    """کلیک دکمه اجرا"""
    query = update.callback_query
    await query.answer()
    user = query.from_user
    context.user_data["state"] = f"A_{lang.upper()}_PROJECT_NAME"
    context.user_data["a_run_step"] = step

    await query.message.reply_text(
        f"🚀 {user.first_name} عزیز، درخواست اجرای ربات شما دریافت شد!\n\n"
        "✏️ لطفاً یک نام برای پروژه ربات خود انتخاب و ارسال کنید 👇\n\n"
        "📌 نکته: نام پروژه بعداً برای مدیریت و شناسایی ربات شما استفاده می‌شود."
    )


async def cb_a_next(update: Update, context: ContextTypes.DEFAULT_TYPE, lang: str, step: int):
    """کلیک دکمه ادامه فایل‌ها"""
    query = update.callback_query
    await query.answer()
    user = query.from_user
    next_step = step + 1
    context.user_data["a_step"] = next_step
    context.user_data["state"] = f"A_{lang.upper()}_FILE"

    num_fa = NUMS_FA[next_step] if next_step <= 10 else str(next_step)
    files = context.user_data.get("a_files", [])
    count = len(files)

    await query.message.reply_text(
        f"📂 {user.first_name} عزیز، لطفاً فایل {num_fa} را ارسال کنید 👇\n\n"
        f"📊 وضعیت آپلود: {count} از ۱۰ فایل\n\n"
        "📌 یادآوری: امکان آپلود تا ۱۰ فایل برای یک ربات وجود دارد."
    )


async def handle_project_name_a(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """دریافت نام پروژه و اجرا در بخش A"""
    user = update.effective_user
    lang = context.user_data.get("a_lang", "Python")
    project_name = update.message.text.strip()

    context.user_data["state"] = "MAIN_MENU"

    await update.message.reply_text(
        f"✅ {user.first_name} عزیز، نام پروژه با موفقیت ثبت شد! 🟢\n\n"
        "⚙️ در حال راه‌اندازی و اجرای دائمی ربات شما...\n"
        "⏳ لطفاً منتظر بمانید، این فرآیند حدود ۱ دقیقه زمان می‌برد.\n"
        "🔄 لطفاً ربات را نبندید و صبور باشید..."
    )

    success, error = await simulate_run_bot(project_name, lang)

    if not success:
        await update.message.reply_text(
            f"❌ {user.first_name} عزیز، متأسفانه اجرای ربات ناموفق بود!\n\n"
            "⚠️ دلایل احتمالی خطا:\n"
            "🔹 وجود مشکل در کدهای فایل\n"
            "🔹 خطای سیستمی\n"
            "🔹 خطای ترمینال\n"
            "🔹 سایر دلایل احتمالی\n\n"
            f"🖥️ جزئیات خطا:\nCode : {{{error or 'خطای ناشناخته'}}}\n\n"
            "🔧 برای رفع مشکل:\n"
            "✅ کدهای خود را بررسی و اصلاح کنید\n"
            "✅ فایل معتبر و سالم ارسال کنید\n"
            "✅ دوباره تلاش کنید\n\n"
            "🏠 برای بازگشت به منوی اصلی از دکمه زیر اقدام کنید 👇\n"
            "🍀 موفق باشید!",
            reply_markup=kb_back_main(),
        )
    else:
        emoji = "🐘" if lang == "PHP" else "🐍"
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        await add_bot(user.id, project_name, lang, "direct")

        await update.message.reply_text(
            f"🎉 {user.first_name} عزیز، تبریک! ربات شما با موفقیت اجرا شد!\n\n"
            f"{emoji} زبان: {lang}\n"
            f"📅 تاریخ اجرا: {now}\n"
            "🟢 وضعیت: فعال\n\n"
            "⚙️ از بخش مدیریت ربات می‌توانید:\n"
            "🔹 ربات را فعال کنید\n"
            "🔹 ربات را غیرفعال کنید\n"
            "🔹 ربات را حذف کنید\n\n"
            "🏠 برای بازگشت به منوی اصلی از دکمه زیر اقدام کنید 👇\n"
            "🍀 موفق و پیروز باشید!",
            reply_markup=kb_back_main(),
        )
