"""
📦 Section B - اجرا ربات با فایل ZIP
"""
import asyncio
import logging
import os
import tempfile
from datetime import datetime
from telegram import Update
from telegram.ext import ContextTypes
from handlers.keyboards import kb_b_lang, kb_b_php_run, kb_b_py_run, kb_back_main
from utils.helpers import validate_zip, simulate_run_bot
from utils.database import add_bot
from config import Config

logger = logging.getLogger(__name__)


async def enter_section_b(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """ورود به بخش B"""
    user = update.effective_user
    context.user_data["section"] = "B"
    context.user_data["b_lang"] = None
    context.user_data["state"] = "B_LANG_SELECT"

    await update.message.reply_text(
        f"👋 {user.first_name} عزیز!\n\n"
        "🤖 برای اجرای ربات تلگرامی از طریق فایل ZIP، لطفاً زبان برنامه‌نویسی مورد نظر خود را انتخاب کنید 👇\n\n"
        "⚙️ سیستم ما از دو زبان پیشرفته پشتیبانی می‌کند:\n\n"
        "🐘 PHP\n"
        "🐍 Python\n\n"
        "🍀 موفق باشید!",
        reply_markup=kb_b_lang(),
    )


async def cb_b_select_lang(update: Update, context: ContextTypes.DEFAULT_TYPE, lang: str):
    """انتخاب زبان در بخش B"""
    query = update.callback_query
    await query.answer()
    user = query.from_user
    context.user_data["b_lang"] = lang
    context.user_data["state"] = f"B_{lang.upper()}_ZIP"

    emoji = "🐘" if lang == "PHP" else "🐍"
    await query.message.reply_text(
        f"✅ {user.first_name} عزیز، زبان {emoji} {lang} با موفقیت انتخاب شد!\n\n"
        "📦 حالا فایل ZIP ربات خود را ارسال کنید 👇\n\n"
        "📌 نکته: فایل ZIP باید شامل تمام فایل‌های ربات شما باشد.\n"
        "📊 وضعیت: منتظر دریافت فایل ZIP..."
    )


async def handle_zip_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """دریافت فایل ZIP"""
    user = update.effective_user
    lang = context.user_data.get("b_lang", "Python")

    doc = update.message.document
    is_valid = False

    if doc and (doc.file_name or "").lower().endswith(".zip"):
        # Download and validate
        try:
            file = await doc.get_file()
            with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
                await file.download_to_drive(tmp.name)
                is_valid = validate_zip(tmp.name)
                context.user_data["b_zip_path"] = tmp.name
        except Exception as e:
            logger.error(f"ZIP download error: {e}")
            is_valid = False

    if not is_valid:
        await update.message.reply_text(
            f"❌ {user.first_name} عزیز، فایل ZIP ارسالی نامعتبر است!\n\n"
            "⚠️ دلایل احتمالی:\n"
            "🔹 فرمت فایل ZIP پشتیبانی نمی‌شود\n"
            "🔹 فایل ZIP آسیب‌دیده یا ناقص است\n"
            "🔹 ساختار داخلی ZIP دارای مشکل است\n\n"
            "🔄 لطفاً فایل را بررسی کرده و دوباره ارسال کنید.\n"
            f"در صورت ادامه مشکل با پشتیبانی تماس بگیرید 👇\n"
            f"📩 {Config.SUPPORT_USERNAME}"
        )
        return

    kb = kb_b_php_run() if lang == "PHP" else kb_b_py_run()
    await update.message.reply_text(
        f"✅ {user.first_name} عزیز، فایل ZIP با موفقیت دریافت شد! 🟢\n\n"
        "📦 وضعیت: آپلود موفق\n"
        "🔓 در حال استخراج فایل‌ها...\n\n"
        "برای اجرای ربات روی دکمه زیر بزنید 👇",
        reply_markup=kb,
    )
    context.user_data["state"] = f"B_{lang.upper()}_READY"


async def cb_b_run(update: Update, context: ContextTypes.DEFAULT_TYPE, lang: str):
    """کلیک دکمه اجرا در بخش B"""
    query = update.callback_query
    await query.answer()
    user = query.from_user
    context.user_data["state"] = f"B_{lang.upper()}_PROJECT_NAME"

    await query.message.reply_text(
        f"🚀 {user.first_name} عزیز، درخواست اجرای ربات شما دریافت شد!\n\n"
        "✏️ لطفاً یک نام برای پروژه ربات خود انتخاب و ارسال کنید 👇\n\n"
        "📌 نکته: نام پروژه بعداً برای مدیریت و شناسایی ربات شما استفاده می‌شود."
    )


async def handle_project_name_b(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """دریافت نام پروژه و اجرا در بخش B"""
    user = update.effective_user
    lang = context.user_data.get("b_lang", "Python")
    project_name = update.message.text.strip()
    context.user_data["state"] = "MAIN_MENU"

    await update.message.reply_text(
        f"✅ {user.first_name} عزیز، نام پروژه با موفقیت ثبت شد! 🟢\n\n"
        "⚙️ در حال راه‌اندازی و اجرای دائمی ربات شما...\n"
        "⏳ لطفاً منتظر بمانید، این فرآیند حدود ۱ دقیقه زمان می‌برد.\n"
        "🔄 لطفاً ربات را نبندید و صبور باشید..."
    )

    success, error = await simulate_run_bot(project_name, lang)

    if not success:
        await update.message.reply_text(
            f"❌ {user.first_name} عزیز، متأسفانه اجرای ربات ناموفق بود!\n\n"
            "⚠️ دلایل احتمالی خطا:\n"
            "🔹 وجود مشکل در کدهای داخل ZIP\n"
            "🔹 ساختار نادرست پوشه‌بندی فایل ZIP\n"
            "🔹 خطای سیستمی\n"
            "🔹 خطای ترمینال\n\n"
            f"🖥️ جزئیات خطا:\nCode : {{{error or 'خطای ناشناخته'}}}\n\n"
            "🔧 برای رفع مشکل:\n"
            "✅ ساختار فایل ZIP را بررسی کنید\n"
            "✅ فایل ZIP معتبر و سالم ارسال کنید\n"
            "✅ دوباره تلاش کنید\n\n"
            "🏠 برای بازگشت به منوی اصلی از دکمه زیر اقدام کنید 👇\n"
            "🍀 موفق باشید!",
            reply_markup=kb_back_main(),
        )
    else:
        emoji = "🐘" if lang == "PHP" else "🐍"
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        await add_bot(user.id, project_name, lang, "zip")

        await update.message.reply_text(
            f"🎉 {user.first_name} عزیز، تبریک! ربات شما با موفقیت اجرا شد!\n\n"
            f"{emoji} زبان: {lang}\n"
            "📦 نوع اجرا: فایل ZIP\n"
            f"📅 تاریخ اجرا: {now}\n"
            "🟢 وضعیت: فعال\n\n"
            "⚙️ از بخش مدیریت ربات می‌توانید:\n"
            "🔹 ربات را فعال کنید\n"
            "🔹 ربات را غیرفعال کنید\n"
            "🔹 ربات را حذف کنید\n\n"
            "🏠 برای بازگشت به منوی اصلی از دکمه زیر اقدام کنید 👇\n"
            "🍀 موفق و پیروز باشید!",
            reply_markup=kb_back_main(),
        )
