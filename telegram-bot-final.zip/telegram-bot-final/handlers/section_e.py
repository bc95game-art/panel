"""
☎️ Section E - پشتیبانی
"""
from telegram import Update
from telegram.ext import ContextTypes
from handlers.keyboards import kb_back_main
from config import Config


async def enter_section_e(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    await update.message.reply_text(
        f"☎️ {user.first_name} عزیز، به بخش پشتیبانی خوش اومدی!\n\n"
        "━━━━━━━━━━━━━━━\n"
        "🟢 وضعیت پشتیبانی: آنلاین\n"
        "━━━━━━━━━━━━━━━\n\n"
        "📌 برای ارتباط با تیم پشتیبانی از روش‌های زیر اقدام کنید 👇\n\n"
        f"📩 آیدی پشتیبانی: {Config.SUPPORT_USERNAME}\n\n"
        "━━━━━━━━━━━━━━━\n"
        "⏰ ساعات پاسخگویی\n"
        "━━━━━━━━━━━━━━━\n"
        "🕗 شنبه تا چهارشنبه: ۸ صبح تا ۱۰ شب\n"
        "🕗 پنجشنبه و جمعه: ۱۰ صبح تا ۸ شب\n\n"
        "━━━━━━━━━━━━━━━\n"
        "📋 قبل از تماس آماده کنید\n"
        "━━━━━━━━━━━━━━━\n"
        "🔹 نام پروژه ربات\n"
        "🔹 زبان برنامه‌نویسی استفاده شده\n"
        "🔹 توضیح دقیق مشکل\n"
        "🔹 تصویر یا متن خطا (در صورت وجود)\n\n"
        "━━━━━━━━━━━━━━━\n\n"
        "⚠️ لطفاً از ارسال پیام‌های تکراری خودداری کنید.\n"
        "🕐 میانگین زمان پاسخگویی: حداکثر ۲۴ ساعت\n\n"
        "🏠 برای بازگشت به منوی اصلی از دکمه زیر اقدام کنید 👇\n"
        "🍀 موفق باشید!",
        reply_markup=kb_back_main(),
    )
