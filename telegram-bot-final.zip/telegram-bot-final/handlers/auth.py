"""
🔐 Auth Handler
"""
import logging
from telegram import Update
from telegram.ext import ContextTypes
from config import Config
from handlers.keyboards import kb_welcome, kb_main_menu
from utils.database import save_user

logger = logging.getLogger(__name__)

_failed: dict = {}
_banned: set = set()


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /start → اگر قبلاً وارد شده مستقیم به منوی اصلی، وگرنه صفحه خوش‌آمد
    """
    user = update.effective_user
    name = user.first_name

    # اگر احراز هویت شده: مستقیم منوی اصلی
    if context.user_data.get("authenticated"):
        await save_user(user.id, user.username, user.first_name)
        await update.message.reply_text(
            f"🎉 سلام {name} عزیز!\n"
            "✅ ورود شما با موفقیت انجام شد، خوش اومدی!\n\n"
            "برای استفاده از امکانات ربات، از دکمه‌های منوی اصلی زیر اقدام کنید 👇\n\n"
            "🍀 موفق و پیروز باشید!",
            reply_markup=kb_main_menu(),
        )
        return

    # صفحه خوش‌آمد با دکمه پسورد
    await update.message.reply_text(
        "🤖 به پیشرفته‌ترین پلتفرم اجرای ربات تلگرامی خوش آمدید! 👋\n\n"
        "با پشتیبانی از زبان‌های PHP و Python، کدنویسی حرفه‌ای را تجربه کنید.\n\n"
        "✅ اجرای مستقیم فایل کد ربات تلگرامی\n"
        "✅ اجرای فایل‌های ZIP حاوی کد ربات\n"
        "✅ امکانات متنوع و جذاب دیگر\n\n"
        "📌 در صورت بروز هرگونه مشکل، با پشتیبانی ربات تماس بگیرید.",
        reply_markup=kb_welcome(),
    )
    context.user_data["state"] = "WAIT_PASSWORD"


async def cb_ask_password(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """کلیک روی دکمه وارد کردن پسورد"""
    query = update.callback_query
    await query.answer()
    user = query.from_user

    if user.id in _banned:
        await query.message.reply_text("🚫 دسترسی شما مسدود شده است.")
        return

    await query.message.reply_text(
        f"👋 سلام {user.first_name} عزیز، خوش اومدی!\n\n"
        "🔐 برای ورود به ربات، لطفاً پسورد کاربری خود را وارد کنید:"
    )
    context.user_data["state"] = "WAIT_PASSWORD"


async def handle_password(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """بررسی پسورد ارسال‌شده"""
    user = update.effective_user
    text = update.message.text.strip()

    if user.id in _banned:
        await update.message.reply_text("🚫 دسترسی مسدود شده است.")
        return False

    if text == Config.BOT_PASSWORD:
        context.user_data["authenticated"] = True
        context.user_data["state"] = "MAIN_MENU"
        _failed.pop(user.id, None)
        await save_user(user.id, user.username, user.first_name)

        await update.message.reply_text(
            "✅ پسورد تأیید شد!\n"
            "🔄 در حال انتقال به صفحه اصلی...\n"
            "لحظه‌ای صبر کنید ⏳"
        )
        import asyncio
        await asyncio.sleep(2)

        await update.message.reply_text(
            f"🎉 سلام {user.first_name} عزیز!\n"
            "✅ ورود شما با موفقیت انجام شد، خوش اومدی!\n\n"
            "برای استفاده از امکانات ربات، از دکمه‌های منوی اصلی زیر اقدام کنید 👇\n\n"
            "🍀 موفق و پیروز باشید!",
            reply_markup=kb_main_menu(),
        )
        return True
    else:
        _failed[user.id] = _failed.get(user.id, 0) + 1
        remaining = Config.MAX_ATTEMPTS - _failed[user.id]

        if _failed[user.id] >= Config.MAX_ATTEMPTS:
            _banned.add(user.id)
            await update.message.reply_text(
                "🚫 دسترسی مسدود شد!\n\n"
                f"شما {Config.MAX_ATTEMPTS} بار پسورد اشتباه وارد کردید.\n"
                f"با پشتیبانی تماس بگیرید: {Config.SUPPORT_USERNAME}"
            )
        else:
            await update.message.reply_text(
                "❌ پسورد وارد شده اشتباه است!\n\n"
                "لطفاً پسورد صحیح را وارد کنید.\n"
                "در صورتی که پسورد ندارید، از پشتیبانی دریافت کنید 👇\n"
                f"📩 پشتیبانی: {Config.SUPPORT_USERNAME}\n\n"
                f"⚠️ {remaining} تلاش باقی مانده"
            )
        return False
