"""
🤖 Main Bot - Router
"""
import logging
import asyncio
from telegram import Update
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, filters, ContextTypes,
)
from config import Config
from utils.database import init_db
from handlers.auth import cmd_start, cb_ask_password, handle_password
from handlers.keyboards import kb_main_menu
from handlers.section_a import (
    enter_section_a, cb_a_select_lang,
    handle_file_upload, cb_a_run, cb_a_next,
    handle_project_name_a,
)
from handlers.section_b import (
    enter_section_b, cb_b_select_lang,
    handle_zip_upload, cb_b_run, handle_project_name_b,
)
from handlers.section_c import enter_section_c
from handlers.section_d import (
    enter_section_d, cb_d_activate, cb_d_deactivate,
    cb_d_delete_confirm, cb_d_do_delete, cb_d_cancel_delete,
)
from handlers.section_e import enter_section_e

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
    handlers=[logging.FileHandler("bot.log"), logging.StreamHandler()],
)
logger = logging.getLogger(__name__)


# ─── Text message router ───────────────────────────────────────────────────────
async def text_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    state = context.user_data.get("state", "")
    text = update.message.text

    # ── Password check ──
    if state == "WAIT_PASSWORD":
        await handle_password(update, context)
        return

    # ── Not authenticated ──
    if not context.user_data.get("authenticated"):
        await update.message.reply_text("⚠️ لطفاً ابتدا /start را بزنید.")
        return

    # ── Main menu buttons ──
    if text == "📁 اجرا ربات تلگرامی با کد فایل 🔥":
        await enter_section_a(update, context)
    elif text == "📁 اجرا ربات تلگرامی با کد فایل ZIP 🔥":
        await enter_section_b(update, context)
    elif text == "👤 پنل کاربری مشخصات کاربر ♻️":
        await enter_section_c(update, context)
    elif text == "💰 پنل مدیریت ربات های اجرا شده 📡":
        await enter_section_d(update, context)
    elif text == "☎️ پشتیبانی ـ admin 🟢":
        await enter_section_e(update, context)

    # ── Project name for section A ──
    elif state in ("A_PHP_PROJECT_NAME", "A_PY_PROJECT_NAME"):
        await handle_project_name_a(update, context)

    # ── Project name for section B ──
    elif state in ("B_PHP_PROJECT_NAME", "B_PY_PROJECT_NAME"):
        await handle_project_name_b(update, context)

    # ── File upload ──
    else:
        await update.message.reply_text(
            "❓ گزینه مورد نظر شما یافت نشد.\n"
            "لطفاً از دکمه‌های منو استفاده کنید.",
            reply_markup=kb_main_menu(),
        )


# ─── Document/File router ──────────────────────────────────────────────────────
async def file_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.user_data.get("authenticated"):
        await update.message.reply_text("⚠️ لطفاً ابتدا /start را بزنید.")
        return

    state = context.user_data.get("state", "")
    if state in ("A_PHP_FILE", "A_PY_FILE"):
        await handle_file_upload(update, context)
    elif state in ("B_PHP_ZIP", "B_PY_ZIP"):
        await handle_zip_upload(update, context)
    else:
        await update.message.reply_text(
            "⚠️ در این مرحله نیازی به ارسال فایل نیست.\n"
            "لطفاً از منو استفاده کنید.",
            reply_markup=kb_main_menu(),
        )


# ─── Callback query router ────────────────────────────────────────────────────
async def callback_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data

    # Welcome → ask password
    if data == "ask_password":
        await cb_ask_password(update, context)

    # Back to main
    elif data == "back_main":
        await query.answer()
        user = query.from_user
        context.user_data["state"] = "MAIN_MENU"
        await query.message.reply_text(
            f"🎉 سلام {user.first_name} عزیز!\n"
            "✅ ورود شما با موفقیت انجام شد، خوش اومدی!\n\n"
            "برای استفاده از امکانات ربات، از دکمه‌های منوی اصلی زیر اقدام کنید 👇\n\n"
            "🍀 موفق و پیروز باشید!",
            reply_markup=kb_main_menu(),
        )

    # Section A: language select
    elif data == "a_php":
        context.user_data["state"] = "A_PHP_FILE"
        await cb_a_select_lang(update, context, "PHP")
    elif data == "a_py":
        context.user_data["state"] = "A_PY_FILE"
        await cb_a_select_lang(update, context, "Python")

    # Section A: run button  a_php_run_N / a_py_run_N
    elif data.startswith("a_php_run_"):
        step = int(data.split("_")[-1])
        await cb_a_run(update, context, "PHP", step)
        context.user_data["state"] = "A_PHP_PROJECT_NAME"
    elif data.startswith("a_py_run_"):
        step = int(data.split("_")[-1])
        await cb_a_run(update, context, "Python", step)
        context.user_data["state"] = "A_PY_PROJECT_NAME"

    # Section A: next file  a_php_next_N / a_py_next_N
    elif data.startswith("a_php_next_"):
        step = int(data.split("_")[-1])
        await cb_a_next(update, context, "PHP", step)
    elif data.startswith("a_py_next_"):
        step = int(data.split("_")[-1])
        await cb_a_next(update, context, "Python", step)

    # Section B: language select
    elif data == "b_php":
        context.user_data["state"] = "B_PHP_ZIP"
        await cb_b_select_lang(update, context, "PHP")
    elif data == "b_py":
        context.user_data["state"] = "B_PY_ZIP"
        await cb_b_select_lang(update, context, "Python")

    # Section B: run
    elif data == "b_php_run":
        await cb_b_run(update, context, "PHP")
        context.user_data["state"] = "B_PHP_PROJECT_NAME"
    elif data == "b_py_run":
        await cb_b_run(update, context, "Python")
        context.user_data["state"] = "B_PY_PROJECT_NAME"

    # Section D: manage
    elif data.startswith("d_activate_"):
        bot_id = int(data.split("_")[-1])
        await cb_d_activate(update, context, bot_id)
    elif data.startswith("d_deactivate_"):
        bot_id = int(data.split("_")[-1])
        await cb_d_deactivate(update, context, bot_id)
    elif data.startswith("d_delete_"):
        bot_id = int(data.split("_")[-1])
        await cb_d_delete_confirm(update, context, bot_id)
    elif data.startswith("d_confirm_del_"):
        bot_id = int(data.split("_")[-1])
        await cb_d_do_delete(update, context, bot_id)
    elif data.startswith("d_cancel_del_"):
        await cb_d_cancel_delete(update, context)

    else:
        await query.answer("⚠️ دستور ناشناخته", show_alert=True)


# ─── App setup ────────────────────────────────────────────────────────────────
async def post_init(app: Application):
    await init_db()
    logger.info("✅ Bot started!")


def create_app() -> Application:
    app = (
        Application.builder()
        .token(Config.BOT_TOKEN)
        .post_init(post_init)
        .build()
    )

    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CallbackQueryHandler(callback_router))
    app.add_handler(MessageHandler(filters.Document.ALL, file_router))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_router))

    return app


def main():
    Config.validate() if hasattr(Config, 'validate') else None
    app = create_app()

    if Config.WEBHOOK_URL:
        logger.info("🚀 Webhook mode")
        app.run_webhook(
            listen="0.0.0.0",
            port=Config.PORT,
            secret_token=Config.WEBHOOK_SECRET,
            webhook_url=f"{Config.WEBHOOK_URL}/webhook/{Config.BOT_TOKEN}",
        )
    else:
        logger.info("🔄 Polling mode")
        app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)


if __name__ == "__main__":
    main()
