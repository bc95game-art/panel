"""
⚙️ Bot Configuration
"""
import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    # ── Telegram ──
    BOT_TOKEN: str = os.getenv("BOT_TOKEN", "8872113046:AAFIQtmkRN3fLsL4CAglUK4sP8CC-NFCNeE")

    # ── Password ──
    BOT_PASSWORD: str = os.getenv("BOT_PASSWORD", "code_wallt_4496_reza_vip")
    MAX_ATTEMPTS: int = int(os.getenv("MAX_ATTEMPTS", "3"))

    # ── Admin ──
    ADMIN_IDS: list = [
        int(x.strip())
        for x in os.getenv("ADMIN_IDS", "").split(",")
        if x.strip().isdigit()
    ]
    SUPPORT_USERNAME: str = os.getenv("SUPPORT_USERNAME", "@AADMINAL3567UMC")

    # ── Webhook ──
    WEBHOOK_URL: str = os.getenv("WEBHOOK_URL", "")
    WEBHOOK_SECRET: str = os.getenv("WEBHOOK_SECRET", "secret_token_xyz")
    PORT: int = int(os.getenv("PORT", "8443"))

    # ── DB ──
    DB_PATH: str = os.getenv("DB_PATH", "bot_data.db")
