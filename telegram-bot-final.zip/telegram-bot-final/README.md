# 🤖 ربات تلگرامی پیشرفته - CodeWallet VIP

پلتفرم اجرای ربات تلگرامی با پشتیبانی از PHP و Python، دارای سیستم احراز هویت با پسورد.

---

## ✅ امکانات

- 🔐 سیستم ورود با پسورد
- 📁 اجرای ربات با فایل مستقیم (تا ۱۰ فایل، PHP/Python)
- 📦 اجرای ربات با فایل ZIP (PHP/Python)
- 👤 پنل کاربری با آمار کامل
- 💰 مدیریت ربات‌های اجرا‌شده (فعال/غیرفعال/حذف)
- ☎️ بخش پشتیبانی
- 🔄 پشتیبانی از Polling و Webhook

---

## 🚀 راه‌اندازی محلی (Polling)

```bash
# ۱. Clone مخزن
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git
cd YOUR_REPO

# ۲. نصب وابستگی‌ها
pip install -r requirements.txt

# ۳. ساخت فایل .env
cp .env.example .env
# فایل .env را باز کرده و BOT_TOKEN را پر کنید

# ۴. اجرا
python bot.py
```

---

## ☁️ راه‌اندازی روی Render.com (Webhook)

### مرحله ۱ - آپلود به GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

### مرحله ۲ - اتصال به Render
1. وارد [render.com](https://render.com) شوید
2. روی **New → Web Service** کلیک کنید
3. مخزن GitHub را انتخاب کنید
4. تنظیمات:
   - **Environment:** Python
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python bot.py`

### مرحله ۳ - متغیرهای محیطی در Render
در داشبورد Render → **Environment** این مقادیر را اضافه کنید:

| کلید | مقدار |
|------|-------|
| `BOT_TOKEN` | توکن ربات از BotFather |
| `WEBHOOK_URL` | آدرس کامل سرویس Render (مثلاً `https://your-app.onrender.com`) |
| `BOT_PASSWORD` | `code_wallt_4496_reza_vip` |
| `ADMIN_IDS` | آیدی عددی تلگرام شما |
| `SUPPORT_USERNAME` | `@AADMINAL3567UMC` |

### مرحله ۴ - Deploy Hook برای CI/CD (اختیاری)
1. در Render: **Settings → Deploy Hook** را کپی کنید
2. در GitHub: **Settings → Secrets → Actions** → اضافه کنید با نام `RENDER_DEPLOY_HOOK`

---

## 📁 ساختار پروژه

```
telegram-bot/
├── bot.py                  # فایل اصلی و روتر
├── config.py               # تنظیمات
├── requirements.txt
├── render.yaml             # تنظیمات Render
├── .env.example
├── .gitignore
├── handlers/
│   ├── auth.py             # سیستم پسورد
│   ├── keyboards.py        # تمام کیبوردها
│   ├── section_a.py        # اجرا با فایل مستقیم
│   ├── section_b.py        # اجرا با ZIP
│   ├── section_c.py        # پنل کاربری
│   ├── section_d.py        # مدیریت ربات‌ها
│   └── section_e.py        # پشتیبانی
├── utils/
│   ├── database.py         # SQLite async
│   └── helpers.py          # توابع کمکی
└── .github/
    └── workflows/
        └── deploy.yml      # CI/CD
```

---

## 🔐 پسورد پیش‌فرض

```
code_wallt_4496_reza_vip
```

برای تغییر پسورد، متغیر `BOT_PASSWORD` را در فایل `.env` یا Render تغییر دهید.

---

## ⚠️ نکات مهم

- توکن ربات را **هرگز** در GitHub آپلود نکنید (فایل `.env` در `.gitignore` است)
- برای Render رایگان، اگر سرویس ۱۵ دقیقه بی‌فعالیت باشد خواب می‌رود؛ با [UptimeRobot](https://uptimerobot.com) آن را بیدار نگه دارید
- توکن خود را از `@BotFather` در تلگرام بگیرید
