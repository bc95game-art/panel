"""
🛠️ Helper utilities
"""
import asyncio
import subprocess
import os
import zipfile
import tempfile
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

ALLOWED_EXTENSIONS = {
    "PHP": [".php", ".json", ".env", ".txt", ".xml", ".ini"],
    "Python": [".py", ".txt", ".json", ".env", ".cfg", ".ini", ".toml", ".yaml", ".yml"],
}


def validate_file(filename: str, language: str) -> bool:
    ext = os.path.splitext(filename)[-1].lower()
    return ext in ALLOWED_EXTENSIONS.get(language, [])


def validate_zip(filepath: str) -> bool:
    try:
        with zipfile.ZipFile(filepath, 'r') as zf:
            names = zf.namelist()
            return len(names) > 0
    except Exception:
        return False


async def simulate_run_bot(project_name: str, language: str) -> tuple[bool, str]:
    """
    Simulate running a bot project.
    In production: replace with actual subprocess execution.
    Returns (success: bool, error_detail: str)
    """
    await asyncio.sleep(3)  # simulate processing
    # In real deployment, run actual subprocess here:
    # result = subprocess.run(["python", "main.py"], capture_output=True, timeout=60)
    # For demo: always succeeds
    return True, ""


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M")
