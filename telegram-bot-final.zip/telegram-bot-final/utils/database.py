"""
🗄️ Database Utility
"""
import aiosqlite
import logging
from datetime import datetime
from config import Config

logger = logging.getLogger(__name__)
DB_PATH = Config.DB_PATH


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                joined_at TEXT DEFAULT CURRENT_TIMESTAMP,
                last_seen TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS bots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                project_name TEXT NOT NULL,
                language TEXT NOT NULL,
                run_type TEXT NOT NULL,
                status TEXT DEFAULT 'active',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.commit()
    logger.info("✅ Database initialized")


async def save_user(user_id: int, username: str, first_name: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT OR REPLACE INTO users (id, username, first_name, last_seen)
            VALUES (?, ?, ?, ?)
        """, (user_id, username or "", first_name or "", datetime.now().isoformat()))
        await db.commit()


async def get_user(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT * FROM users WHERE id = ?", (user_id,)) as cur:
            return await cur.fetchone()


async def add_bot(user_id: int, project_name: str, language: str, run_type: str) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("""
            INSERT INTO bots (user_id, project_name, language, run_type, status, created_at)
            VALUES (?, ?, ?, ?, 'active', ?)
        """, (user_id, project_name, language, run_type, datetime.now().strftime("%Y-%m-%d %H:%M")))
        await db.commit()
        return cur.lastrowid


async def get_user_bots(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT * FROM bots WHERE user_id = ? ORDER BY created_at DESC", (user_id,)
        ) as cur:
            return await cur.fetchall()


async def update_bot_status(bot_id: int, status: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE bots SET status = ? WHERE id = ?", (status, bot_id))
        await db.commit()


async def delete_bot(bot_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM bots WHERE id = ?", (bot_id,))
        await db.commit()


async def get_user_stats(user_id: int) -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        user_row = await db.execute("SELECT joined_at FROM users WHERE id = ?", (user_id,))
        user = await user_row.fetchone()
        joined = user[0] if user else "نامشخص"

        total = await (await db.execute("SELECT COUNT(*) FROM bots WHERE user_id = ?", (user_id,))).fetchone()
        php = await (await db.execute("SELECT COUNT(*) FROM bots WHERE user_id = ? AND language = 'PHP'", (user_id,))).fetchone()
        python = await (await db.execute("SELECT COUNT(*) FROM bots WHERE user_id = ? AND language = 'Python'", (user_id,))).fetchone()
        direct = await (await db.execute("SELECT COUNT(*) FROM bots WHERE user_id = ? AND run_type = 'direct'", (user_id,))).fetchone()
        zipf = await (await db.execute("SELECT COUNT(*) FROM bots WHERE user_id = ? AND run_type = 'zip'", (user_id,))).fetchone()
        active = await (await db.execute("SELECT COUNT(*) FROM bots WHERE user_id = ? AND status = 'active'", (user_id,))).fetchone()
        inactive = await (await db.execute("SELECT COUNT(*) FROM bots WHERE user_id = ? AND status = 'inactive'", (user_id,))).fetchone()

    return {
        "joined": joined,
        "total": total[0] if total else 0,
        "php": php[0] if php else 0,
        "python": python[0] if python else 0,
        "direct": direct[0] if direct else 0,
        "zip": zipf[0] if zipf else 0,
        "active": active[0] if active else 0,
        "inactive": inactive[0] if inactive else 0,
    }
